﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculadora_Simples
{
    public partial class Form1 : Form
    {
        double numero1, numero2, resultado;//Global

        private void BtnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void TxtNum1_TextChanged(object sender, EventArgs e)
        {
            if(!(double.TryParse(txtNum1.Text, out numero1)))
            {
                if (txtNum1.Text != "")
                {
                    MessageBox.Show("Número Inválido!");
                    txtNum1.Focus();
                    txtNum1.Text = "";
                }
            }
        }

        private void TxtNum2_TextChanged(object sender, EventArgs e)
        {
            if(!(double.TryParse(txtNum2.Text, out numero2)))
            {
                if (txtNum2.Text != "")
                {
                    MessageBox.Show("Número Inválido!");
                    txtNum2.Focus();
                    txtNum2.Text = "";
                }
            }
        }

        private void BtnSoma_Click(object sender, EventArgs e)
        {
            resultado = numero1 + numero2;
            txtResultado.Text = resultado.ToString();
        }

        private void BtnSub_Click(object sender, EventArgs e)
        {
            resultado = numero1 - numero2;
            txtResultado.Text = resultado.ToString();
        }

        private void BtnMult_Click(object sender, EventArgs e)
        {
            resultado = numero1 * numero2;
            txtResultado.Text = resultado.ToString();
        }

        private void BtnDiv_Click(object sender, EventArgs e)
        {
            if (numero2 == 0)
            {
                MessageBox.Show("O divisor deve ser diferente de 0");
                txtNum2.Text = "";
                txtNum2.Focus();
            }
            else
            {
                resultado = numero1 / numero2;
                txtResultado.Text = resultado.ToString();
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void BtnLimpa_Click(object sender, EventArgs e)
        {
            txtNum1.Text = "";
            txtNum2.Text = "";
            txtResultado.Text = "";
        }
    }
}
