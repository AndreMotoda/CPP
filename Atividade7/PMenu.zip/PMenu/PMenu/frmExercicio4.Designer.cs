﻿namespace PMenu
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxtFrase = new System.Windows.Forms.RichTextBox();
            this.btnCaracNum = new System.Windows.Forms.Button();
            this.btnCaracBranco = new System.Windows.Forms.Button();
            this.btnCaracAlfa = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchtxtFrase
            // 
            this.rchtxtFrase.Location = new System.Drawing.Point(265, 88);
            this.rchtxtFrase.Margin = new System.Windows.Forms.Padding(2);
            this.rchtxtFrase.Name = "rchtxtFrase";
            this.rchtxtFrase.Size = new System.Drawing.Size(236, 79);
            this.rchtxtFrase.TabIndex = 9;
            this.rchtxtFrase.Text = "";
            this.rchtxtFrase.TextChanged += new System.EventHandler(this.RchtxtFrase_TextChanged);
            // 
            // btnCaracNum
            // 
            this.btnCaracNum.Location = new System.Drawing.Point(276, 199);
            this.btnCaracNum.Name = "btnCaracNum";
            this.btnCaracNum.Size = new System.Drawing.Size(210, 23);
            this.btnCaracNum.TabIndex = 10;
            this.btnCaracNum.Text = "Quantidade de Caracteres Numéricos";
            this.btnCaracNum.UseVisualStyleBackColor = true;
            this.btnCaracNum.Click += new System.EventHandler(this.BtnCaracNum_Click);
            // 
            // btnCaracBranco
            // 
            this.btnCaracBranco.Location = new System.Drawing.Point(276, 228);
            this.btnCaracBranco.Name = "btnCaracBranco";
            this.btnCaracBranco.Size = new System.Drawing.Size(210, 23);
            this.btnCaracBranco.TabIndex = 11;
            this.btnCaracBranco.Text = "Posição primeiro Caracter Branco";
            this.btnCaracBranco.UseVisualStyleBackColor = true;
            this.btnCaracBranco.Click += new System.EventHandler(this.BtnCaracBranco_Click);
            // 
            // btnCaracAlfa
            // 
            this.btnCaracAlfa.Location = new System.Drawing.Point(276, 257);
            this.btnCaracAlfa.Name = "btnCaracAlfa";
            this.btnCaracAlfa.Size = new System.Drawing.Size(210, 23);
            this.btnCaracAlfa.TabIndex = 12;
            this.btnCaracAlfa.Text = "Quantidade de Caracteres Alfabéticos";
            this.btnCaracAlfa.UseVisualStyleBackColor = true;
            this.btnCaracAlfa.Click += new System.EventHandler(this.BtnCaracAlfa_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnCaracAlfa);
            this.Controls.Add(this.btnCaracBranco);
            this.Controls.Add(this.btnCaracNum);
            this.Controls.Add(this.rchtxtFrase);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtFrase;
        private System.Windows.Forms.Button btnCaracNum;
        private System.Windows.Forms.Button btnCaracBranco;
        private System.Windows.Forms.Button btnCaracAlfa;
    }
}