﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMenu
{
    public partial class frn : Component
    {
        public frn()
        {
            InitializeComponent();
        }

        public frn(IContainer container)
        {
            container.Add(this);

            InitializeComponent();
        }
    }
}
