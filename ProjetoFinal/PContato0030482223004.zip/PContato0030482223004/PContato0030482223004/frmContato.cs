﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace PContato0030482223004
{
    public partial class frmContato : Form
    {

        private BindingSource bnContato = new BindingSource();
        private bool bInclusao = false;
        private DataSet dsContato = new DataSet();
        private DataSet dsCidade = new DataSet();

        public frmContato()
        {
            InitializeComponent();
        }

        private void frmContato_Load(object sender, EventArgs e)
        {
            try
            {
                Contato Con = new Contato();
                dsContato.Tables.Add(Con.Listar());
                bnContato.DataSource = dsContato.Tables["Contato"];
                dgvContato.DataSource = bnContato;
                bnvContato.BindingSource = bnContato;
                txtIdcontato.DataBindings.Add("TEXT", bnContato, "id_contato");
                txtNomecontato.DataBindings.Add("TEXT", bnContato, "nome_contato");
                txtEndereco.DataBindings.Add("TEXT", bnContato, "end_contato");
                txtCelular.DataBindings.Add("TEXT", bnContato, "cel_contato");
                txtEmail.DataBindings.Add("TEXT", bnContato, "email_contato");
                dtpData.DataBindings.Add("TEXT", bnContato, "dtcadastro_contato");

                Cidade Cid = new Cidade();
                dsCidade.Tables.Add(Cid.Listar());
                cbxCidade.DataSource = dsCidade.Tables["Cidade"];

                cbxCidade.DisplayMember = "nome_cidade";

                cbxCidade.ValueMember = "id_cidade";

                cbxCidade.DataBindings.Add("SelectedValue", bnContato, "cidade_id_cidade");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            if (tbContato.SelectedIndex == 0)
            {
                tbContato.SelectTab(1);
            }
            bnContato.AddNew();
            txtNomecontato.Enabled = true;
            cbxCidade.Enabled = true;
            cbxCidade.SelectedIndex = 0;
            txtNomecontato.Focus();
            txtCelular.Enabled = true;
            txtEmail.Enabled = true;
            txtEndereco.Enabled = true;
            dtpData.Enabled = true;
            btnSalvar.Enabled = true;
            btnAlterar.Enabled = false;
            btnNovo.Enabled = false;
            btnExcluir.Enabled = false;
            btnCancelar.Enabled = true;
            bInclusao = true;
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            if (txtNomecontato.Text == "")
            {
                MessageBox.Show("Nome inválido!");
            }
            else
            if (txtCelular.Text == "")
            {
                MessageBox.Show("Celular inválido!");
            }
            else
            if (txtEmail.Text == "")
            {
                MessageBox.Show("E-mail inválido!");
            }
            else
            if (txtEndereco.Text == "")
            {
                MessageBox.Show("Endereço inválido!");
            }
            else
                {
                Contato RegCid = new Contato();
                RegCid.Idcontato = Convert.ToInt16(txtIdcontato.Text);
                RegCid.Nomecontato = txtNomecontato.Text;
                RegCid.Endcontato = txtEndereco.Text;
                RegCid.Cidadeidcidade = Convert.ToInt32(cbxCidade.SelectedValue.ToString());
                RegCid.Celcontato = txtCelular.Text;
                RegCid.Emailcontato = txtEmail.Text;
                RegCid.Dtcadastro = dtpData.Value;
                if (bInclusao)
                {
                    if (RegCid.Salvar() > 0)
                    {
                        MessageBox.Show("Contato adicionado com sucesso!");
                        btnSalvar.Enabled = false;
                        txtIdcontato.Enabled = false;
                        txtNomecontato.Enabled = false;
                        cbxCidade.Enabled = false;
                        txtEndereco.Enabled = false;
                        txtEmail.Enabled = false;
                        txtCelular.Enabled = false;
                        dtpData.Enabled = false;
                        btnSalvar.Enabled = false;
                        btnAlterar.Enabled = true;
                        btnNovo.Enabled = true;
                        btnExcluir.Enabled = true;
                        btnCancelar.Enabled = false;
                        bInclusao = false;
                        dsContato.Tables.Clear();
                        dsContato.Tables.Add(RegCid.Listar());
                        bnContato.DataSource = dsContato.Tables["Contato"];
                    }
                    else
                    {
                        MessageBox.Show("Erro ao gravar contato!");
                    }
                }
                else
                {
                    if (RegCid.Alterar() > 0)
                    {
                        MessageBox.Show("Contato alterado com sucesso!");
                        dsContato.Tables.Clear();
                        dsContato.Tables.Add(RegCid.Listar());
                        txtIdcontato.Enabled = false;
                        txtNomecontato.Enabled = false;
                        cbxCidade.Enabled = false;
                        txtEndereco.Enabled = false;
                        txtEmail.Enabled = false;
                        dtpData.Enabled = false;
                        txtCelular.Enabled = false;
                        btnSalvar.Enabled = false;
                        btnAlterar.Enabled = true;
                        btnNovo.Enabled = true;
                        btnExcluir.Enabled = true;
                        btnCancelar.Enabled = false;
                    }
                    else
                    {
                        MessageBox.Show("Erro ao gravar Contato!");
                    }
                }
            }
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            if (tbContato.SelectedIndex == 0)
            {
                tbContato.SelectTab(1);
            }
            txtNomecontato.Enabled = true;
            cbxCidade.Enabled = true;
            txtNomecontato.Focus();
            txtCelular.Enabled = true;
            txtEmail.Enabled = true;
            txtEndereco.Enabled = true;
            txtNomecontato.Enabled = true;
            dtpData.Enabled = true;
            btnSalvar.Enabled = true;
            btnAlterar.Enabled = false;
            btnNovo.Enabled = false;
            btnExcluir.Enabled = false;
            btnCancelar.Enabled = true;
            bInclusao = false;
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {

            if (tbContato.SelectedIndex == 0)
            {
                tbContato.SelectTab(1);
            }
            if (MessageBox.Show("Confirma exclusão?", "Yes or No",
           MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2)
           == DialogResult.Yes)
            {
                Contato RegCid = new Contato();
                RegCid.Idcontato = Convert.ToInt16(txtIdcontato.Text);
                RegCid.Nomecontato = txtNomecontato.Text;
                RegCid.Endcontato = txtEndereco.Text;
                RegCid.Cidadeidcidade = cbxCidade.SelectedIndex;
                RegCid.Celcontato = txtCelular.Text;
                RegCid.Emailcontato = txtEndereco.Text;
                RegCid.Dtcadastro = dtpData.Value;
                if (RegCid.Excluir() > 0)
                {
                    MessageBox.Show("Contato excluído com sucesso!");
                    Contato R = new Contato();
                    dsContato.Tables.Clear();
                    dsContato.Tables.Add(R.Listar());
                    bnContato.DataSource = dsContato.Tables["Contato"];
                }
                else
                {
                    MessageBox.Show("Erro ao excluir contato!");
                }
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            bnContato.CancelEdit();
            btnSalvar.Enabled = false;
            txtNomecontato.Enabled = false;
            cbxCidade.Enabled = false;
            txtCelular.Enabled = false;
            txtEmail.Enabled = false;
            txtEndereco.Enabled = false;
            txtIdcontato.Enabled = false;
            txtNomecontato.Enabled = false;
            dtpData.Enabled = false;
            btnAlterar.Enabled = true;
            btnNovo.Enabled = true;
            btnExcluir.Enabled = true;
        }
    }
}
