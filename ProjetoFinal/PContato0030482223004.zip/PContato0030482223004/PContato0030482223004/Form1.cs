﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace PContato0030482223004
{
    public partial class FrmPrincipal : Form
    {

        public static SqlConnection conexao = new SqlConnection("Data Source=DESKTOP-9NKC3JH\\SQLSERVER2022;Initial Catalog=LP2;Integrated Security=True");
        public FrmPrincipal()
        {
            InitializeComponent();
        }
        private void FrmPrincipal_Load(object sender, EventArgs e)
        {
            try
            {   
                conexao.Open();
            }
            catch(SqlException ex)
            {
                MessageBox.Show("Erro de banco de dados =/" + ex.Message);
            }
            catch(Exception ex)
            {
                MessageBox.Show("Outros Erros =/" + ex.Message);
            }
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void cToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmCidade>().Count() > 0)
            {
                MessageBox.Show("Form ja existe!");
                Application.OpenForms["frmCidade"].BringToFront();
            }
            else
            {
                frmCidade frmCi = new frmCidade();
                frmCi.MdiParent = this;
                frmCi.WindowState = FormWindowState.Maximized;
                frmCi.Show();
            }
        }

        private void contatoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmContato>().Count() > 0)
            {
                MessageBox.Show("Form ja existe!");
                Application.OpenForms["frmContato"].BringToFront();
            }
            else
            {
                frmContato frmCo = new frmContato();
                frmCo.MdiParent = this;
                frmCo.WindowState = FormWindowState.Maximized;
                frmCo.Show();
            }
        }
        private void sobreToolStripMenuItem_Click(object sender, EventArgs e)
        {

            if (Application.OpenForms.OfType<frmSobre>().Count() > 0)
            {
                MessageBox.Show("Form ja existe!");
                Application.OpenForms["frmSobre"].BringToFront();
            }
            else
            {
                frmSobre frmSo = new frmSobre();
                frmSo.MdiParent = this;
                frmSo.WindowState = FormWindowState.Maximized;
                frmSo.Show();
            }
        }
    }
}
