﻿
namespace Atividade_5
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.mskbxSalBruto = new System.Windows.Forms.MaskedTextBox();
            this.btnDesconto = new System.Windows.Forms.Button();
            this.lblDados = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.ckbxCasado = new System.Windows.Forms.CheckBox();
            this.txtDescIRPF = new System.Windows.Forms.TextBox();
            this.txtDescINSS = new System.Windows.Forms.TextBox();
            this.txtSalLiquido = new System.Windows.Forms.TextBox();
            this.txtSalFamilia = new System.Windows.Forms.TextBox();
            this.txtAliqIRPF = new System.Windows.Forms.TextBox();
            this.txtAliqINSS = new System.Windows.Forms.TextBox();
            this.lblDescIRPF = new System.Windows.Forms.Label();
            this.lblDescINSS = new System.Windows.Forms.Label();
            this.lblSalLiquido = new System.Windows.Forms.Label();
            this.lblSalFamilia = new System.Windows.Forms.Label();
            this.lblAliqIRPF = new System.Windows.Forms.Label();
            this.lblAliqINSS = new System.Windows.Forms.Label();
            this.gbxSexo = new System.Windows.Forms.GroupBox();
            this.rbtnM = new System.Windows.Forms.RadioButton();
            this.rbtnF = new System.Windows.Forms.RadioButton();
            this.nupdFilhos = new System.Windows.Forms.NumericUpDown();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.lblFilhos = new System.Windows.Forms.Label();
            this.lblSalBruto = new System.Windows.Forms.Label();
            this.lblNome = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.gbxSexo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nupdFilhos)).BeginInit();
            this.SuspendLayout();
            // 
            // mskbxSalBruto
            // 
            this.mskbxSalBruto.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mskbxSalBruto.Location = new System.Drawing.Point(219, 175);
            this.mskbxSalBruto.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.mskbxSalBruto.Mask = "99990.00";
            this.mskbxSalBruto.Name = "mskbxSalBruto";
            this.mskbxSalBruto.Size = new System.Drawing.Size(106, 30);
            this.mskbxSalBruto.TabIndex = 46;
            // 
            // btnDesconto
            // 
            this.btnDesconto.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDesconto.Location = new System.Drawing.Point(394, 289);
            this.btnDesconto.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnDesconto.Name = "btnDesconto";
            this.btnDesconto.Size = new System.Drawing.Size(227, 39);
            this.btnDesconto.TabIndex = 45;
            this.btnDesconto.Text = "Verifica Desconto";
            this.btnDesconto.UseVisualStyleBackColor = true;
            this.btnDesconto.Click += new System.EventHandler(this.btnDesconto_Click);
            // 
            // lblDados
            // 
            this.lblDados.AutoSize = true;
            this.lblDados.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDados.Location = new System.Drawing.Point(214, 368);
            this.lblDados.Name = "lblDados";
            this.lblDados.Size = new System.Drawing.Size(0, 24);
            this.lblDados.TabIndex = 44;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.ckbxCasado);
            this.panel1.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.panel1.Location = new System.Drawing.Point(804, 128);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(102, 110);
            this.panel1.TabIndex = 43;
            // 
            // ckbxCasado
            // 
            this.ckbxCasado.AutoSize = true;
            this.ckbxCasado.Location = new System.Drawing.Point(9, 39);
            this.ckbxCasado.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ckbxCasado.Name = "ckbxCasado";
            this.ckbxCasado.Size = new System.Drawing.Size(88, 28);
            this.ckbxCasado.TabIndex = 7;
            this.ckbxCasado.Text = "Casado";
            this.ckbxCasado.UseVisualStyleBackColor = true;
            // 
            // txtDescIRPF
            // 
            this.txtDescIRPF.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDescIRPF.Location = new System.Drawing.Point(673, 496);
            this.txtDescIRPF.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtDescIRPF.Name = "txtDescIRPF";
            this.txtDescIRPF.ReadOnly = true;
            this.txtDescIRPF.Size = new System.Drawing.Size(261, 30);
            this.txtDescIRPF.TabIndex = 41;
            // 
            // txtDescINSS
            // 
            this.txtDescINSS.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDescINSS.Location = new System.Drawing.Point(673, 449);
            this.txtDescINSS.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtDescINSS.Name = "txtDescINSS";
            this.txtDescINSS.ReadOnly = true;
            this.txtDescINSS.Size = new System.Drawing.Size(261, 30);
            this.txtDescINSS.TabIndex = 40;
            // 
            // txtSalLiquido
            // 
            this.txtSalLiquido.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSalLiquido.Location = new System.Drawing.Point(219, 584);
            this.txtSalLiquido.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtSalLiquido.Name = "txtSalLiquido";
            this.txtSalLiquido.ReadOnly = true;
            this.txtSalLiquido.Size = new System.Drawing.Size(280, 30);
            this.txtSalLiquido.TabIndex = 39;
            // 
            // txtSalFamilia
            // 
            this.txtSalFamilia.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSalFamilia.Location = new System.Drawing.Point(219, 541);
            this.txtSalFamilia.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtSalFamilia.Name = "txtSalFamilia";
            this.txtSalFamilia.ReadOnly = true;
            this.txtSalFamilia.Size = new System.Drawing.Size(280, 30);
            this.txtSalFamilia.TabIndex = 38;
            // 
            // txtAliqIRPF
            // 
            this.txtAliqIRPF.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAliqIRPF.Location = new System.Drawing.Point(219, 496);
            this.txtAliqIRPF.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtAliqIRPF.Name = "txtAliqIRPF";
            this.txtAliqIRPF.ReadOnly = true;
            this.txtAliqIRPF.Size = new System.Drawing.Size(280, 30);
            this.txtAliqIRPF.TabIndex = 37;
            // 
            // txtAliqINSS
            // 
            this.txtAliqINSS.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAliqINSS.Location = new System.Drawing.Point(219, 449);
            this.txtAliqINSS.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtAliqINSS.Name = "txtAliqINSS";
            this.txtAliqINSS.ReadOnly = true;
            this.txtAliqINSS.Size = new System.Drawing.Size(280, 30);
            this.txtAliqINSS.TabIndex = 36;
            // 
            // lblDescIRPF
            // 
            this.lblDescIRPF.AutoSize = true;
            this.lblDescIRPF.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescIRPF.Location = new System.Drawing.Point(544, 499);
            this.lblDescIRPF.Name = "lblDescIRPF";
            this.lblDescIRPF.Size = new System.Drawing.Size(122, 24);
            this.lblDescIRPF.TabIndex = 35;
            this.lblDescIRPF.Text = "Desconto IRPF";
            // 
            // lblDescINSS
            // 
            this.lblDescINSS.AutoSize = true;
            this.lblDescINSS.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescINSS.Location = new System.Drawing.Point(544, 452);
            this.lblDescINSS.Name = "lblDescINSS";
            this.lblDescINSS.Size = new System.Drawing.Size(123, 24);
            this.lblDescINSS.TabIndex = 34;
            this.lblDescINSS.Text = "Desconto INSS";
            // 
            // lblSalLiquido
            // 
            this.lblSalLiquido.AutoSize = true;
            this.lblSalLiquido.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalLiquido.Location = new System.Drawing.Point(75, 587);
            this.lblSalLiquido.Name = "lblSalLiquido";
            this.lblSalLiquido.Size = new System.Drawing.Size(117, 24);
            this.lblSalLiquido.TabIndex = 33;
            this.lblSalLiquido.Text = "Salário Líquido";
            // 
            // lblSalFamilia
            // 
            this.lblSalFamilia.AutoSize = true;
            this.lblSalFamilia.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalFamilia.Location = new System.Drawing.Point(77, 544);
            this.lblSalFamilia.Name = "lblSalFamilia";
            this.lblSalFamilia.Size = new System.Drawing.Size(118, 24);
            this.lblSalFamilia.TabIndex = 32;
            this.lblSalFamilia.Text = "Salário Família";
            // 
            // lblAliqIRPF
            // 
            this.lblAliqIRPF.AutoSize = true;
            this.lblAliqIRPF.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAliqIRPF.Location = new System.Drawing.Point(75, 499);
            this.lblAliqIRPF.Name = "lblAliqIRPF";
            this.lblAliqIRPF.Size = new System.Drawing.Size(113, 24);
            this.lblAliqIRPF.TabIndex = 31;
            this.lblAliqIRPF.Text = "Alíquota IRPF";
            // 
            // lblAliqINSS
            // 
            this.lblAliqINSS.AutoSize = true;
            this.lblAliqINSS.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAliqINSS.Location = new System.Drawing.Point(75, 452);
            this.lblAliqINSS.Name = "lblAliqINSS";
            this.lblAliqINSS.Size = new System.Drawing.Size(114, 24);
            this.lblAliqINSS.TabIndex = 30;
            this.lblAliqINSS.Text = "Alíquota INSS";
            // 
            // gbxSexo
            // 
            this.gbxSexo.Controls.Add(this.rbtnM);
            this.gbxSexo.Controls.Add(this.rbtnF);
            this.gbxSexo.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbxSexo.Location = new System.Drawing.Point(644, 128);
            this.gbxSexo.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.gbxSexo.Name = "gbxSexo";
            this.gbxSexo.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.gbxSexo.Size = new System.Drawing.Size(100, 110);
            this.gbxSexo.TabIndex = 29;
            this.gbxSexo.TabStop = false;
            this.gbxSexo.Text = "Sexo";
            // 
            // rbtnM
            // 
            this.rbtnM.AutoSize = true;
            this.rbtnM.Checked = true;
            this.rbtnM.Location = new System.Drawing.Point(15, 23);
            this.rbtnM.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rbtnM.Name = "rbtnM";
            this.rbtnM.Size = new System.Drawing.Size(46, 28);
            this.rbtnM.TabIndex = 1;
            this.rbtnM.TabStop = true;
            this.rbtnM.Text = "M";
            this.rbtnM.UseVisualStyleBackColor = true;
            // 
            // rbtnF
            // 
            this.rbtnF.AutoSize = true;
            this.rbtnF.Location = new System.Drawing.Point(15, 52);
            this.rbtnF.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rbtnF.Name = "rbtnF";
            this.rbtnF.Size = new System.Drawing.Size(41, 28);
            this.rbtnF.TabIndex = 0;
            this.rbtnF.Text = "F";
            this.rbtnF.UseVisualStyleBackColor = true;
            // 
            // nupdFilhos
            // 
            this.nupdFilhos.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nupdFilhos.Location = new System.Drawing.Point(219, 222);
            this.nupdFilhos.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.nupdFilhos.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.nupdFilhos.Name = "nupdFilhos";
            this.nupdFilhos.Size = new System.Drawing.Size(106, 30);
            this.nupdFilhos.TabIndex = 42;
            // 
            // txtNome
            // 
            this.txtNome.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNome.Location = new System.Drawing.Point(219, 128);
            this.txtNome.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(280, 30);
            this.txtNome.TabIndex = 28;
            // 
            // lblFilhos
            // 
            this.lblFilhos.AutoSize = true;
            this.lblFilhos.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFilhos.Location = new System.Drawing.Point(75, 222);
            this.lblFilhos.Name = "lblFilhos";
            this.lblFilhos.Size = new System.Drawing.Size(134, 24);
            this.lblFilhos.TabIndex = 27;
            this.lblFilhos.Text = "Número de filhos";
            // 
            // lblSalBruto
            // 
            this.lblSalBruto.AutoSize = true;
            this.lblSalBruto.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalBruto.Location = new System.Drawing.Point(75, 175);
            this.lblSalBruto.Name = "lblSalBruto";
            this.lblSalBruto.Size = new System.Drawing.Size(103, 24);
            this.lblSalBruto.TabIndex = 26;
            this.lblSalBruto.Text = "Salário Bruto";
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNome.Location = new System.Drawing.Point(75, 128);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(138, 24);
            this.lblNome.TabIndex = 25;
            this.lblNome.Text = "Nome funcionário";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1033, 769);
            this.Controls.Add(this.mskbxSalBruto);
            this.Controls.Add(this.btnDesconto);
            this.Controls.Add(this.lblDados);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.txtDescIRPF);
            this.Controls.Add(this.txtDescINSS);
            this.Controls.Add(this.txtSalLiquido);
            this.Controls.Add(this.txtSalFamilia);
            this.Controls.Add(this.txtAliqIRPF);
            this.Controls.Add(this.txtAliqINSS);
            this.Controls.Add(this.lblDescIRPF);
            this.Controls.Add(this.lblDescINSS);
            this.Controls.Add(this.lblSalLiquido);
            this.Controls.Add(this.lblSalFamilia);
            this.Controls.Add(this.lblAliqIRPF);
            this.Controls.Add(this.lblAliqINSS);
            this.Controls.Add(this.gbxSexo);
            this.Controls.Add(this.nupdFilhos);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.lblFilhos);
            this.Controls.Add(this.lblSalBruto);
            this.Controls.Add(this.lblNome);
            this.Font = new System.Drawing.Font("Arial Narrow", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.gbxSexo.ResumeLayout(false);
            this.gbxSexo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nupdFilhos)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MaskedTextBox mskbxSalBruto;
        private System.Windows.Forms.Button btnDesconto;
        private System.Windows.Forms.Label lblDados;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.CheckBox ckbxCasado;
        private System.Windows.Forms.TextBox txtDescIRPF;
        private System.Windows.Forms.TextBox txtDescINSS;
        private System.Windows.Forms.TextBox txtSalLiquido;
        private System.Windows.Forms.TextBox txtSalFamilia;
        private System.Windows.Forms.TextBox txtAliqIRPF;
        private System.Windows.Forms.TextBox txtAliqINSS;
        private System.Windows.Forms.Label lblDescIRPF;
        private System.Windows.Forms.Label lblDescINSS;
        private System.Windows.Forms.Label lblSalLiquido;
        private System.Windows.Forms.Label lblSalFamilia;
        private System.Windows.Forms.Label lblAliqIRPF;
        private System.Windows.Forms.Label lblAliqINSS;
        private System.Windows.Forms.GroupBox gbxSexo;
        private System.Windows.Forms.RadioButton rbtnM;
        private System.Windows.Forms.RadioButton rbtnF;
        private System.Windows.Forms.NumericUpDown nupdFilhos;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.Label lblFilhos;
        private System.Windows.Forms.Label lblSalBruto;
        private System.Windows.Forms.Label lblNome;
    }
}

