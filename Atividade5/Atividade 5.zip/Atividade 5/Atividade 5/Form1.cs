﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnDesconto_Click(object sender, EventArgs e)
        {

            lblDados.Visible = true;

            double descINSS = 0;
            double descIRPF = 0;
            double salarioLiquido = 0;
            double salarioBruto = 0;
            double salarioFamilia = 0;
            double filhos = 0;

            if (txtNome.Text == String.Empty)
                MessageBox.Show("O nome do funcionário\nnão pode ser vazio");
            else
            {
                if (mskbxSalBruto.Text.Replace(",", "").Trim() == "")
                    MessageBox.Show("Não digitou salário");

                else if (!double.TryParse(mskbxSalBruto.Text, out salarioBruto))
                    MessageBox.Show("Salário bruto deve ser um número");
                else
                {
                    if (salarioBruto <= 0)
                        MessageBox.Show("Salário bruto deve ser maior que 0");

                    else
                    {
                        if (salarioBruto <= 800.47)
                        {
                            txtAliqINSS.Text = "7,65%";
                            descINSS = 0.0765 * salarioBruto;
                        }
                        else if (salarioBruto <= 1050)
                        {
                            txtAliqINSS.Text = "8,65%";
                            descINSS = 0.0865 * salarioBruto;
                        }
                        else if (salarioBruto <= 1400.77)
                        {
                            txtAliqINSS.Text = "9,00%";
                            descINSS = 0.09 * salarioBruto;
                        }
                        else if (salarioBruto <= 2801.56)
                        {
                            txtAliqINSS.Text = "11,00%";
                            descINSS = 0.11 * salarioBruto;
                        }
                        else
                        {
                            txtAliqINSS.Text = "Teto";
                            descINSS = 308.17;
                        }

                        txtDescINSS.Text = descINSS.ToString("N2");

                        if (salarioBruto <= 1257.12)
                            txtAliqIRPF.Text = "0";
                        else if (salarioBruto <= 2512.08)
                        {
                            txtAliqIRPF.Text = "15%";
                            descIRPF = 0.15 * salarioBruto;
                        }
                        else
                        {
                            txtAliqIRPF.Text = "27,5%";
                            descIRPF = 0.275 * salarioBruto;
                        }

                        txtDescIRPF.Text = descIRPF.ToString("N2");

                        filhos = Convert.ToDouble((decimal)nupdFilhos.Value);

                        if (filhos > 0)
                        {
                            if (salarioBruto <= 435.52)
                                salarioFamilia = 22.33 * filhos;
                            else if (salarioBruto <= 654.61)
                                salarioFamilia = 15.74 * filhos;
                            else
                                salarioFamilia = 0;
                        }

                        txtSalFamilia.Text = salarioFamilia.ToString("N2");

                        salarioLiquido = salarioBruto - descINSS - descIRPF + salarioFamilia;

                        txtSalLiquido.Text = salarioLiquido.ToString("N2");

                        lblDados.Text = "Os descontos do salário de " + txtNome.Text +
                            " que possui o estado civil " + (ckbxCasado.Checked ? "casado(a)" : "solteiro(a)") +
                            " e que tem " + Convert.ToString(filhos) + " filho(s) são:";
                    }
                }
            }
        }
    }
}
