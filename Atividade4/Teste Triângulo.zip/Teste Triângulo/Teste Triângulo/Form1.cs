﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Teste_Triângulo
{
    public partial class Form1 : Form
    {
        double Lado1, Lado2, Lado3;

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtLado1.Clear();
            txtLado2.Clear();
            txtLado3.Clear();
            txtTipo.Clear();
        }

        private void txtLado1_TextChanged(object sender, EventArgs e)
        {
            if ((!double.TryParse(txtLado1.Text, out Lado1)) && txtLado1.Text != "")
            {
                MessageBox.Show("Dado inválido");
                txtLado1.Clear();
                txtLado1.Focus();
            }
        }

        private void txtLado2_TextChanged(object sender, EventArgs e)
        {
            if ((!double.TryParse(txtLado2.Text, out Lado2)) && txtLado2.Text != "")
            {
                MessageBox.Show("Dado inválido");
                txtLado2.Clear();
                txtLado2.Focus();
            }
        }

        private void txtLado3_TextChanged(object sender, EventArgs e)
        {
            if ((!double.TryParse(txtLado3.Text, out Lado3)) && txtLado3.Text != "")
            {
                MessageBox.Show("Dado inválido");
                txtLado3.Clear();
                txtLado3.Focus();
            }
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void BtnVerificar_Click(object sender, EventArgs e)
        {
            if(double.TryParse(txtLado1.Text, out Lado1) && double.TryParse(txtLado2.Text, out Lado2) 
                && double.TryParse(txtLado3.Text, out Lado3))
            {
                if (Math.Abs(Lado1 - Lado2) < Lado3 && Lado3 < Lado1 + Lado2 && Math.Abs(Lado2 - Lado3) < Lado1 && Lado1 < Lado2 + Lado3
                    && Math.Abs(Lado3 - Lado1) < Lado2 && Lado2 < Lado3 + Lado1)
                {
                    if (Lado1 == Lado2 || Lado2 == Lado3 || Lado3 == Lado1)
                    {
                        if (Lado1 == Lado2 && Lado2 == Lado3)
                            txtTipo.Text = "Triângulo Equilátero";
                        else
                            txtTipo.Text = "Triângulo Isósceles";
                    }
                    else
                        txtTipo.Text = "Triângulo Escaleno";
                }
                else
                    txtTipo.Text = "Não é um triângulo";
            }
        }
    }
}
