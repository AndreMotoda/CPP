﻿namespace ATIVIDADE_9
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnInverte = new System.Windows.Forms.Button();
            this.lstbxGeral = new System.Windows.Forms.ListBox();
            this.btnMercado = new System.Windows.Forms.Button();
            this.btnMedia = new System.Windows.Forms.Button();
            this.btnQtdeNome = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnInverte
            // 
            this.btnInverte.Font = new System.Drawing.Font("Arial", 12F);
            this.btnInverte.Location = new System.Drawing.Point(73, 50);
            this.btnInverte.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnInverte.Name = "btnInverte";
            this.btnInverte.Size = new System.Drawing.Size(271, 119);
            this.btnInverte.TabIndex = 0;
            this.btnInverte.Text = "Inverter Lista de 20 Números";
            this.btnInverte.UseVisualStyleBackColor = true;
            this.btnInverte.Click += new System.EventHandler(this.BtnInverte_Click);
            // 
            // lstbxGeral
            // 
            this.lstbxGeral.FormattingEnabled = true;
            this.lstbxGeral.ItemHeight = 16;
            this.lstbxGeral.Location = new System.Drawing.Point(777, 345);
            this.lstbxGeral.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.lstbxGeral.Name = "lstbxGeral";
            this.lstbxGeral.Size = new System.Drawing.Size(399, 276);
            this.lstbxGeral.TabIndex = 1;
            // 
            // btnMercado
            // 
            this.btnMercado.Font = new System.Drawing.Font("Arial", 12F);
            this.btnMercado.Location = new System.Drawing.Point(368, 50);
            this.btnMercado.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMercado.Name = "btnMercado";
            this.btnMercado.Size = new System.Drawing.Size(271, 119);
            this.btnMercado.TabIndex = 2;
            this.btnMercado.Text = "Calcular Faturamento mensal";
            this.btnMercado.UseVisualStyleBackColor = true;
            this.btnMercado.Click += new System.EventHandler(this.BtnMercado_Click);
            // 
            // btnMedia
            // 
            this.btnMedia.Font = new System.Drawing.Font("Arial", 12F);
            this.btnMedia.Location = new System.Drawing.Point(663, 50);
            this.btnMedia.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMedia.Name = "btnMedia";
            this.btnMedia.Size = new System.Drawing.Size(271, 119);
            this.btnMedia.TabIndex = 3;
            this.btnMedia.Text = "Calcular Média de 3 notas";
            this.btnMedia.UseVisualStyleBackColor = true;
            this.btnMedia.Click += new System.EventHandler(this.BtnMedia_Click);
            // 
            // btnQtdeNome
            // 
            this.btnQtdeNome.Font = new System.Drawing.Font("Arial", 12F);
            this.btnQtdeNome.Location = new System.Drawing.Point(73, 196);
            this.btnQtdeNome.Margin = new System.Windows.Forms.Padding(4);
            this.btnQtdeNome.Name = "btnQtdeNome";
            this.btnQtdeNome.Size = new System.Drawing.Size(271, 119);
            this.btnQtdeNome.TabIndex = 4;
            this.btnQtdeNome.Text = "Quantidade de caracteres no nome";
            this.btnQtdeNome.UseVisualStyleBackColor = true;
            this.btnQtdeNome.Click += new System.EventHandler(this.btnQtdeNome_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1325, 724);
            this.Controls.Add(this.btnQtdeNome);
            this.Controls.Add(this.btnMedia);
            this.Controls.Add(this.btnMercado);
            this.Controls.Add(this.lstbxGeral);
            this.Controls.Add(this.btnInverte);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnInverte;
        private System.Windows.Forms.ListBox lstbxGeral;
        private System.Windows.Forms.Button btnMercado;
        private System.Windows.Forms.Button btnMedia;
        private System.Windows.Forms.Button btnQtdeNome;
    }
}

