﻿
namespace ATIVIDADE_9
{
    partial class exercicio6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnQtdeNome = new System.Windows.Forms.Button();
            this.lstbxNome = new System.Windows.Forms.ListBox();
            this.btnFechar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnQtdeNome
            // 
            this.btnQtdeNome.Font = new System.Drawing.Font("Arial", 12F);
            this.btnQtdeNome.Location = new System.Drawing.Point(148, 197);
            this.btnQtdeNome.Margin = new System.Windows.Forms.Padding(4);
            this.btnQtdeNome.Name = "btnQtdeNome";
            this.btnQtdeNome.Size = new System.Drawing.Size(271, 119);
            this.btnQtdeNome.TabIndex = 5;
            this.btnQtdeNome.Text = "Quantidade de caracteres no nome";
            this.btnQtdeNome.UseVisualStyleBackColor = true;
            this.btnQtdeNome.Click += new System.EventHandler(this.btnQtdeNome_Click);
            // 
            // lstbxNome
            // 
            this.lstbxNome.FormattingEnabled = true;
            this.lstbxNome.ItemHeight = 16;
            this.lstbxNome.Location = new System.Drawing.Point(589, 80);
            this.lstbxNome.Margin = new System.Windows.Forms.Padding(4);
            this.lstbxNome.Name = "lstbxNome";
            this.lstbxNome.Size = new System.Drawing.Size(363, 388);
            this.lstbxNome.TabIndex = 6;
            // 
            // btnFechar
            // 
            this.btnFechar.Font = new System.Drawing.Font("Arial", 12F);
            this.btnFechar.Location = new System.Drawing.Point(148, 80);
            this.btnFechar.Margin = new System.Windows.Forms.Padding(4);
            this.btnFechar.Name = "btnFechar";
            this.btnFechar.Size = new System.Drawing.Size(207, 77);
            this.btnFechar.TabIndex = 7;
            this.btnFechar.Text = "Fechar";
            this.btnFechar.UseVisualStyleBackColor = true;
            this.btnFechar.Click += new System.EventHandler(this.btnFechar_Click);
            // 
            // exercicio6
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1026, 559);
            this.Controls.Add(this.btnFechar);
            this.Controls.Add(this.lstbxNome);
            this.Controls.Add(this.btnQtdeNome);
            this.Name = "exercicio6";
            this.Text = "exercicio6";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnQtdeNome;
        private System.Windows.Forms.ListBox lstbxNome;
        private System.Windows.Forms.Button btnFechar;
    }
}