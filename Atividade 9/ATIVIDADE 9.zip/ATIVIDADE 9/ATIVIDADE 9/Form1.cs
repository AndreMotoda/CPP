﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace ATIVIDADE_9
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void BtnInverte_Click(object sender, EventArgs e)
        {
            lstbxGeral.Items.Clear();
            int[] Num = new int[20];
            string auxiliar;
            for(var i = 0; i < 20; i++)
            {
                auxiliar = Interaction.InputBox("Digite o número.", "Entrada de texto");
                if(!int.TryParse(auxiliar, out Num[i]))
                    break;
            }
            Array.Reverse(Num);
            foreach (int x in Num)
                lstbxGeral.Items.Add(x.ToString());
        }

        private void BtnMercado_Click(object sender, EventArgs e)
        {
            lstbxGeral.Items.Clear();
            double[] Qtde = new double[10];
            double[] Preco = new double[10];
            double aux = 0;
            string auxiliar;
            for (var i = 0; i < 10; i++)
            {
                auxiliar = Interaction.InputBox("Digite a quantidade do " + (i+1).ToString() + " produto." , "Entrada de texto");
                if (!double.TryParse(auxiliar, out Qtde[i]))
                    break;
                auxiliar = Interaction.InputBox("Digite o preço do " + (i + 1).ToString() + " produto.", "Entrada de texto");
                if (!double.TryParse(auxiliar, out Preco[i]))
                    break;
            }
            for (var i = 0; i < 10; i++)
            {
                aux += Qtde[i] * Preco[i];
            }
                lstbxGeral.Items.Add(aux.ToString());
        }

        private void BtnMedia_Click(object sender, EventArgs e)
        {
            lstbxGeral.Items.Clear();
            double[,] Notas = new double[20, 3];
            double[] Medias = new double[20];
            string auxiliar;
            for (var i = 0; i < 20; i++)
            {
                for (var j = 0; j < 3; j++)
                {
                    auxiliar = Interaction.InputBox("Digite a " + (j + 1).ToString() + " nota do aluno " + (i + 1).ToString(), "Entrada de texto");
                    if (!double.TryParse(auxiliar, out Notas[i, j]))
                        break;
                    Medias[i] += Notas[i, j];
                }
                lstbxGeral.Items.Add("Média de aluno " + (i + 1) + ":" + Medias[i]/3);
            }
        }

        private void btnQtdeNome_Click(object sender, EventArgs e)
        {
            exercicio6 frm6 = new exercicio6();
            frm6.Show();
        }
    }
}
