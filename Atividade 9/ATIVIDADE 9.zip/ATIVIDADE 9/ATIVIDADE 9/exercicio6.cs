﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace ATIVIDADE_9
{
    public partial class exercicio6 : Form
    {
        public exercicio6()
        {
            InitializeComponent();
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnQtdeNome_Click(object sender, EventArgs e)
        {
            string[] Nome = new string[10];
            string auxiliar;
            int cont;
            for (var i = 0; i < 10; i++)
            {
                auxiliar = Interaction.InputBox("Digite o nome", "Entrada de Dados");
                if (auxiliar == "")
                    break;
                Nome[i] = auxiliar;
                cont = Nome[i].Length;
                for (var j = 0; j < Nome[i].Length; j++)
                    if (Nome[i].Substring(j, 1) == " ")
                        cont--;
                lstbxNome.Items.Add("O nome " + Nome[i] + " tem " + cont + " caracteres.");
            }
        }
    }
}
