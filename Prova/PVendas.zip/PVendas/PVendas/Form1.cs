﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PVendas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnVerificar_Click(object sender, EventArgs e)
        {
            double[,] Vendas = new double[4, 4];
            double Mensal, Total = 0;
            string Aux;
            
            for(var i = 0; i < 4; i++)
            {
                Mensal = 0;
                for (var j = 0; j < 4; j++)
                {
                    Aux = Interaction.InputBox("Insira o valor da semana " + (j + 1) + " do mês " + (i + 1) + ":", "Entrada de dados");
                    if (double.TryParse(Aux, out Vendas[i, j]) || Aux == "")
                    {
                        Mensal += Vendas[i, j];
                        lstbxVendas.Items.Add("Total do mês: " + (i + 1) + " Semana " + (j + 1) + ": " + Vendas[i, j].ToString("N2"));
                        if (j == 3)
                        {
                            lstbxVendas.Items.Add(">>Total mês: R$" + Mensal.ToString("N2"));
                            lstbxVendas.Items.Add("----------------------------------------");
                            Total += Mensal;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Valor Inválido, digite novamente.");
                        j--;
                    }
                }
            }
            lstbxVendas.Items.Add(">> Total Geral: R$" + Total.ToString("N2"));
        }

        private void BtnLimpa_Click(object sender, EventArgs e)
        {
            lstbxVendas.Items.Clear();
        }
    }
}
