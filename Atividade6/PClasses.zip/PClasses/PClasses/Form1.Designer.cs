﻿namespace PClasses
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnMes = new System.Windows.Forms.Button();
            this.btnHora = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnMes
            // 
            this.btnMes.Font = new System.Drawing.Font("Arial", 16F);
            this.btnMes.Location = new System.Drawing.Point(163, 169);
            this.btnMes.Name = "btnMes";
            this.btnMes.Size = new System.Drawing.Size(195, 84);
            this.btnMes.TabIndex = 0;
            this.btnMes.Text = "Mensalista";
            this.btnMes.UseVisualStyleBackColor = true;
            this.btnMes.Click += new System.EventHandler(this.BtnMes_Click);
            // 
            // btnHora
            // 
            this.btnHora.Font = new System.Drawing.Font("Arial", 16F);
            this.btnHora.Location = new System.Drawing.Point(438, 169);
            this.btnHora.Name = "btnHora";
            this.btnHora.Size = new System.Drawing.Size(195, 84);
            this.btnHora.TabIndex = 1;
            this.btnHora.Text = "Horista";
            this.btnHora.UseVisualStyleBackColor = true;
            this.btnHora.Click += new System.EventHandler(this.BtnHora_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnHora);
            this.Controls.Add(this.btnMes);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnMes;
        private System.Windows.Forms.Button btnHora;
    }
}

